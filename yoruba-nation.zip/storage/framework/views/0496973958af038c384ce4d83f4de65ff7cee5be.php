<?php $attributes = $attributes->exceptProps(['title' => $title, 'subtitle' => $subtitle]); ?>
<?php foreach (array_filter((['title' => $title, 'subtitle' => $subtitle]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="banner flex items-center">
    <div class="container-x">
        <h4 class="text-sm sm:text-base font-semibold tracking-tight whitespace-nowrap text-primary uppercase">
            <?php echo e($subtitle); ?> </h4>
        <h2 class="text-3xl sm:text-5xl font-bold tracking-tighter  whitespace-nowrap"><?php echo e($title); ?> </h2>
    </div>
</div>


<script>
    gsap.set(".banner h4,.banner h2", {
        width: "0%",
        overflow: 'hidden',

    });

    const anim = gsap.timeline()


    anim.to(".banner h4", {
        width: '100%',
    }).to('.banner h2', {
        width: '100%',
        duration: 2
    })
</script>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/components/banner.blade.php ENDPATH**/ ?>