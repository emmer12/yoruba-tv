<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.banner','data' => ['title' => 'About us','subtitle' => 'Who we are']]); ?>
<?php $component->withName('banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => 'About us','subtitle' => 'Who we are']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>

    <section class="py-[100px] fadeIn">
        <div class="container-x">
            <div class="flex gap-x-[60px] items-center ">
                <div class="display w-full sm:w-1/2  rounded-3xl overflow-clip ">
                    <img src="<?php echo e(asset('images/img1.jpeg')); ?>" />
                </div>
                <div class="w-full sm:w-1/2 ">
                    <h4 class="text-sm sm:text-base font-semibold tracking-tight  text-primary uppercase mb-2">
                        Our Vision</h4>
                    <h2 class="text-3xl sm:text-5xl font-bold tracking-tighter mb-3">We provide high quality services
                    </h2>
                    <p class="text-lg ">
                        Empower viewers with a diverse and immersive TV experience, offering captivating content that
                        entertains, informs, and inspires.
                    </p>

                    <button class="btn btn-primary mt-3">
                        Contact Us
                    </button>
                </div>
            </div>
        </div>
    </section>


    <section class="py-[100px] fadeIn">
        <div class="container-x">
            <div class="sm:w-[600px] m-auto text-center">
                <h4 class="text-sm sm:text-base font-semibold tracking-tight  text-primary uppercase mb-2">
                    Our Mission</h4>
                <h2 class="text-3xl sm:text-5xl font-bold tracking-tighter mb-3">We provide high quality services
                </h2>
                <p class="text-lg ">
                    Empower viewers with a diverse and immersive TV experience, offering captivating content that
                    entertains, informs, and inspires.
                </p>
            </div>


            <div class=" items-center my-4 ">
                <div class="display m-auto w-full sm:w-1/2  rounded-3xl overflow-clip ">
                    <img src="<?php echo e(asset('images/img2.jpeg')); ?>" />
                </div>

            </div>
        </div>
    </section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/pages/about.blade.php ENDPATH**/ ?>