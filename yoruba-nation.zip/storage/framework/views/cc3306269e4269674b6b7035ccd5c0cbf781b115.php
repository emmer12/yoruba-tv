<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <section class="my-[50px]">
        <div class="container-x">
            <div class="card fadeIn  sm:w-1/2 w-full bg-gray-50 rounded-xl p-4 m-auto">
                <div class="mb-2">
                    <h4 class="text-lg  font-semibold text-gray-900">Yoruba Ledership forum</h4>
                    <p>Membership application form</p>
                </div>

                <form method="POST" action="<?php echo e(route('registration')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="grid grid-cols-2 gap-3">
                        <div class="field my-2">
                            <label for="surname">Surname</label>
                            <input name="surname" id="surname" value="<?php echo e(old('surname')); ?>" type="text"
                                class="form-control  <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                        </div>

                        <div class="field my-2">
                            <label for="other_name">Other Name</label>
                            <input name="other_name" id="other_name" value="<?php echo e(old('other_name')); ?>" type="text"
                                class="form-control  <?php $__errorArgs = ['other_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                        </div>
                    </div>
                    <div class="field my-2">
                        <label for="madian_name">Madian Name</label>
                        <input name="madian_name" id="madian_name" value="<?php echo e(old('madian_name')); ?>" type="text"
                            class="form-control  <?php $__errorArgs = ['madian_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="field my-2">
                            <label for="sex">Sex</label>
                            <select name="sex" class="form-select <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>

                        <div class="field my-2">
                            <label for="marital_status">Marital Status</label>
                            <select name="marital_status" class="form-select">
                                <option value="single">Single</option>
                                <option value="married">Married</option>
                                <option value="divorced">Divorced</option>
                                <option value="widowed">Widowed</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div class="field my-2">
                            <label for="religion">Religion</label>
                            <input name="religion" value="<?php echo e(old('religion')); ?>" type="text" class="form-control" />
                        </div>

                        <div class="field my-2">
                            <label for="date_of_birth">Date of Birth</label>
                            <input name="date_of_birth" value="<?php echo e(old('date_of_birth')); ?>" type="date"
                                class="form-control" />
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="field my-2">
                            <label for="home_town">Home Town</label>
                            <input name="home_town" type="text" value="<?php echo e(old('home_town')); ?>"
                                class="form-control" />
                        </div>
                        <div class="field my-2">
                            <label for="lga">Local Government Area (LGA)</label>
                            <input name="lga" id="lga" type="text" value="<?php echo e(old('lga')); ?>"
                                class="form-control" />
                        </div>
                    </div>


                    <div class="field my-2">
                        <label for="home_address">Home Address</label>
                        <textarea name="home_address" class="form-control" value="<?php echo e(old('home_address')); ?>"></textarea>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div class="field my-2">
                            <label for="tel_no">Telephone Number</label>
                            <input name="tel_no" value="<?php echo e(old('tel_no')); ?>" id="tel_no" type="tel"
                                class="form-control" />
                        </div>

                        <div class="field my-2">
                            <label for="education_qualification">Education Qualification</label>
                            <input name="education_qualification" type="text"
                                value="<?php echo e(old('education_qualification')); ?>" class="form-control" />
                        </div>
                    </div>

                    <div class="field my-2">
                        <label for="email">Email Adresss</label>
                        <input name="email" type="email" value="<?php echo e(old('email')); ?>" id="email"
                            class="form-control" />
                    </div>

                    <div class="field my-2">
                        <label for="why_join">Why do you want to join?</label>
                        <textarea name="why_join" value="<?php echo e(old('why_join')); ?>" class="form-control"></textarea>
                    </div>

                    <div class="field my-2">
                        <label for="next_of_kin_details">Next of Kin Details (Name,Phone Number,Address)</label>
                        <textarea name="next_of_kin_details" value="<?php echo e(old('next_of_kin_details')); ?>" class="form-control"></textarea>
                    </div>

                    <div class="my-4 flex justify-center items-center">
                        <label for="photo"
                            class="h-[200px] w-[200px] bg-blue-500 text-center leading-[200px] font-semibold text-base rounded-sm text-white cursor-pointer relative overflow-clip">Affix
                            Photo
                            <img id="display" class="h-full w-full object-contain absolute top-0" />
                        </label>
                        <input type="file" name="photo" id="photo" class="hidden "
                            onchange="handleChange(event)" accept="image/*" />
                    </div>

                    <div class="text-center">
                        <button class="btn btn-primary mt-4 ">
                            Submit
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>


<script>
    const display = document.getElementById('display')

    function handleChange(event) {
        const file = event.target.files[0];
        display.src = URL.createObjectURL(file)
    }
</script>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/pages/ylf-registration.blade.php ENDPATH**/ ?>