


<div class="col-md-6">
    <div class="blog-item">

        <div class='text-center blog-image'>
            <?= $post->image_tag('medium', true, '') ?>
        </div>
        <div class="blog-inner-item">
            
            <h5 class=''><?php echo e($post->subtitle); ?></h5>

            <?php if(config('binshopsblog.show_full_text_at_list')): ?>
                <p><?php echo $post->post_body_output(); ?></p>
            <?php else: ?>
                <p><?php echo mb_strimwidth($post->post_body_output(), 0, 400, '...'); ?></p>
            <?php endif; ?>

            <div class="post-details-bottom">
                <span class="light-text">Authored by: </span> <?php echo e($post->post->author->name); ?> <span
                    class="light-text">Posted at: </span> <?php echo e(date('d M Y ', strtotime($post->post->posted_at))); ?>

            </div>
            <div class='text-center'>
                
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/vendor/binshopsblog/partials/index_loop.blade.php ENDPATH**/ ?>