
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
</script>

<?php $__env->startSection('content'); ?>
    <div>
        <h2>List of YLF Members</h2>
        <div class="card">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Surname</th>
                        <th scope="col">Other Name</th>
                        <th scope="col">Email</th>
                        <th style="text-align: end" scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr data-bs-toggle="collapse" data-bs-target="#collapseOne-<?php echo e($user->id); ?>" aria-expanded="true"
                            aria-controls="collapseOne">
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($user->surname); ?></td>
                            <td><?php echo e($user->other_name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td style="text-align: end">
                                <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">View
                                    Info</button>
                            </td>
                        </tr>

                        <tr>
                            <td colspan="6" class="hiddenRow">
                                <div id="collapseOne-<?php echo e($user->id); ?>"
                                    class=" accordion-collapse collapse accordion-body" aria-labelledby="headingOne"
                                    data-bs-parent="#accordionExample">
                                    <div class="photo">
                                        <img src="/storage/<?php echo e($user->photo); ?>" alt="">
                                    </div>
                                    <div><strong> Madian Name:</strong> <?php echo e($user->madian_name); ?></div>
                                    <div><strong> Sex:</strong> <?php echo e($user->sex); ?></div>
                                    <div><strong> Marital Status:</strong> <?php echo e($user->matital_status); ?></div>
                                    <div><strong> Religon:</strong> <?php echo e($user->religion); ?></div>
                                    <div><strong> Date of birth:</strong> <?php echo e($user->dob); ?></div>
                                    <div><strong> Home Town:</strong> <?php echo e($user->home_town); ?></div>
                                    <div><strong> Local Governmernt Area:</strong> <?php echo e($user->lga); ?></div>
                                    <div><strong> Home Address:</strong> <?php echo e($user->home_address); ?></div>
                                    <div><strong> Telephone Number:</strong> <?php echo e($user->tel_no); ?></div>
                                    <div><strong> Eduation Qualification:</strong> <?php echo e($user->education_qualification); ?>

                                    </div>
                                    <div><strong> Why Join:</strong> <?php echo e($user->why_join); ?></div>
                                    <div><strong> Next of kin Info:</strong> <?php echo e($user->next_of_kin_details); ?></div>
                                    <div><strong> Date Created:</strong> <?php echo e($user->created_at); ?></div>
                                </div>
                            </td>
                        </tr>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-info">
                            No Register member
                        </div>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<style>
    .hiddenRow {
        padding: 0 !important;
    }

    .accordion-body {
        padding: 20px;
    }

    .accordion-body>div {
        margin: 10px 0px;
    }

    .accordion-body div.photo {
        height: 200px;
        width: 200px;
        border: 1px solid #cdcdcd
    }

    .accordion-body div.photo img {
        object-fit: contain;
        height: 100%;
        width: 100%;
    }
</style>


<?php echo $__env->make('binshopsblog_admin::layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/pages/ylf-members.blade.php ENDPATH**/ ?>