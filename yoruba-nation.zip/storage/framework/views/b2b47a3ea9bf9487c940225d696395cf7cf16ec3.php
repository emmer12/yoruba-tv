<section class="w-full sm:w-[640px] m-auto py-6">

    <?php if(\Auth::check() && \Auth::user()->canManageBinshopsBlogPosts()): ?>
        <a href="<?php echo e($post->edit_url()); ?>" class="btn btn-primary">Edit
            Post</a>
    <?php endif; ?>

    <div class="mb-2">
        <h1 class='blog_title font-bold text-2xl sm:text-4xl tracking-tight'><?php echo e($post->title); ?></h1>
        <h5 class='blog_subtitle text-base text-gray-500 font-medium'><?php echo e($post->subtitle); ?></h5>

        <div class="flex gap-3">
            <?php echo $__env->renderWhen($post->author, 'binshopsblog::partials.author', ['post' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
            <div>
                <strong><?php echo e($post->post->posted_at->diffForHumans()); ?></strong>
            </div>
        </div>

    </div>


    <div class="[&>img]:w-full">
        <?= $post->image_tag('medium', false, 'd-block mx-auto') ?>
    </div>

    <p class="blog_body_content my-4">
        <?php echo $post->post_body_output(); ?>


        
        
        
        
        
        
        
    </p>


    <?php echo $__env->renderWhen($categories, 'binshopsblog::partials.categories', ['categories' => $categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
</section>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/vendor/binshopsblog/partials/full_post_details.blade.php ENDPATH**/ ?>