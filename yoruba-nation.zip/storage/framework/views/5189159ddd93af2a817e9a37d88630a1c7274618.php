
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layout','data' => []]); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class='container-x'>
        <div class='row'>
            <div class='col-sm-12 col-md-12 col-lg-12'>

                <?php echo $__env->make('binshopsblog::partials.show_errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('binshopsblog::partials.full_post_details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                <div class="w-full sm:w-[620px] m-auto">
                    <?php if(config('binshopsblog.comments.type_of_comments_to_show', 'built_in') !== 'disabled'): ?>
                        <div class="" id='maincommentscontainer'>
                            <h2 class='font-semibold my-2' id='binshopsblogcomments'>Comments</h2>
                            <?php echo $__env->make('binshopsblog::partials.show_comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php else: ?>
                        
                    <?php endif; ?>
                </div>


            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/vendor/binshopsblog/single_post.blade.php ENDPATH**/ ?>