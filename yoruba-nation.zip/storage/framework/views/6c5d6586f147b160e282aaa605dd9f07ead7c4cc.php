<div style='max-width:500px;margin:50px auto;' class='search-form-outer'>
    <form method='get' action='<?php echo e(route("binshopsblog.search", app('request')->get('locale'))); ?>' class='text-center'>
        <h4>Search for something in our blog:</h4>
        <input type='text' name='s' placeholder='Search...' class='form-control' value='<?php echo e(\Request::get("s")); ?>'>
        <input type='submit' value='Search' class='btn btn-primary m-2'>
    </form>
</div><?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/vendor/binshopsblog/sitewide/search_form.blade.php ENDPATH**/ ?>