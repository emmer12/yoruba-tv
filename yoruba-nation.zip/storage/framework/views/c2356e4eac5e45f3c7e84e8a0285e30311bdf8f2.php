<?php $__env->startSection("content"); ?>


    <h5>Admin - Upload Images</h5>

    <p>Upload was successful.</p>

    <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div>

            <h4><?php echo e($image['filename']); ?></h4>
            <h6>
                <small><?php echo e($image['w'] . "x" . $image['h']); ?></small>
            </h6>

            <a href='<?php echo e(asset(     config("binshopsblog.blog_upload_dir") . "/". $image['filename'])); ?>' target='_blank'>
                <img src='<?php echo e(asset(     config("binshopsblog.blog_upload_dir") . "/". $image['filename'])); ?>'
                     style='max-width:400px; height: auto;'>
            </a>
            <input type='text' readonly='readonly' class='form-control' value='<?php echo e(asset(     config("binshopsblog.blog_upload_dir") . "/". $image['filename'])); ?>'>
            <input type='text' readonly='readonly' class='form-control' value='<?php echo e("<img src='".asset(     config("binshopsblog.blog_upload_dir") . "/". $image['filename'])."' alt='' >"); ?>'>


        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class='alert alert-danger'>No image was processed</div>
    <?php endif; ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make("binshopsblog_admin::layouts.admin_layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/vendor/binshopsblog_admin/imageupload/uploaded.blade.php ENDPATH**/ ?>