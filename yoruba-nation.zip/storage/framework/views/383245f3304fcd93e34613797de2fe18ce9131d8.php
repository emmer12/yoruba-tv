<?php $attributes = $attributes->exceptProps(['post' => $post]); ?>
<?php foreach (array_filter((['post' => $post]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<article class="card-animation flex flex-col  gap-6">
    <div class="blog-card-display h-[181px] w-full rounded-lg overflow-hidden">
        <?= $post->image_tag('medium', true, '') ?>
    </div>
    <div class="flex flex-col gap-2  max-w-full">
        <?php $__currentLoopData = $post->post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $trans =  $category->categoryTranslations->where('lang_id',1)->first();?>
            <h6 class="text-primary font-medium">
                <?php echo e($trans->category_name); ?>

            </h6>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <a href="/post/${article?.slug">
            <h4 class="text-[20px] tracking-[-0.4px] font-bold mb-1">
                <?php echo e($post->title); ?>

            </h4>
        </a>
        <div class="flex items-center gap-[14px] [&>span]:font-medium">
            <span class="text-xs text-[#667185]">
                <?php echo e(date('d M Y ', strtotime($post->post->posted_at))); ?>

            </span>
            <div class="h-2 w-2 bg-[#D0D5DD] rounded-full" />
            <span class="text-xs text-[#667185]">
                <?php echo e($post->content); ?>

            </span>
        </div>
        <div class="author-date flex justify-between items-center">
            

        </div>

    </div>
</article>
<?php /**PATH C:\xampp\htdocs\yoruba-nation\resources\views/components/post-card.blade.php ENDPATH**/ ?>